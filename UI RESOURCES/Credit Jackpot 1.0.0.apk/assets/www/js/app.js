var db, uid, exitPop, last_seen, go, paymentPop, results, updates;
games = new_update = Array();
angular.module('credit', ['ionic', 'ngCordova'])
.config(function($stateProvider, $urlRouterProvider, $ionicConfigProvider) {
  $ionicConfigProvider.views.maxCache(0);
  $stateProvider
  .state('games', {
    url: '/games',
    templateUrl: 'games.html',
    controller : 'gamesCtrl'
  })
  .state('notifications', {
    url: '/notifications',
    templateUrl: 'notifications.html',
    controller : 'notificationsCtrl'
  })
  .state('hotoplay', {
    url: '/howtoplay',address : '+8613601234567',
    templateUrl: 'howtoplay.html',
    controller : 'howtoplayCtrl'
  })
  .state('play-quickpick', {
    url: '/play-quickpick/:id',
    templateUrl: 'play-quickpick.html',
    controller : 'playCtrl'
  })
  .state('play-riddler', {
    url: '/play-riddler/:id',
    templateUrl: 'play-riddler.html',
    controller : 'playCtrl'
  })
  $urlRouterProvider.otherwise("/games");
})

.run(function($ionicPlatform, $state, $ionicPopup, $cordovaSQLite, $http, $timeout, $ionicHistory) {
  ionic.Platform.showStatusBar(false);
  function payment_verification(sms){
    var numb = sms.body.match(/[1-9][0-9]*/g);
    if(numb.length >= 3 && numb[0] == '10201108698'){
      go = false;
      $http.get('http://api.haufy.com/verify_payment.php?uid='+uid+'&amount='+numb[1]).then(function(resp){
          if(resp.data){
            var query1 = "UPDATE Sms SET last_seen = "+sms.date+" where id = 1";
            $cordovaSQLite.execute(db, query1, []).then(function(agent) {
            }, function (err) {
            })
            current_time = parseInt(Date.now());
            var query2 = "INSERT INTO Updates (title, message, type, db_id, time) VALUES (?, ?, ?, ?, ?)";
            $cordovaSQLite.execute(db, query2, [resp.data.title, resp.data.message, 'ticket', resp.data.id, current_time]).then(function(update) {
              new_update.push({'title':resp.data.title, 'message':resp.data.message, 'type':'ticket', 'db_id':resp.data.id, 'time': current_time, 'id':update.insertId});
            }, function (err) {
              alert(JSON.stringify(err));
            })
            last_seen = sms.date;
            cordova.plugins.notification.local.schedule({
              id: resp.data.id,
              title: resp.data.title,
              smallIcon: 'res://ic_popup_reminder',
              text: resp.data.message
            });
          }
        })
    }
  }
  
  document.addEventListener('deviceready', function () {
    if(SMS) SMS.startWatch(function(){
      // alert('stated');
    }, function(){
      // alert('failed');
    });

    setInterval(function () {
      if(SMS) SMS.listSMS({box : 'inbox',address : '+128',maxCount : 5}, function(data){
        data.reverse();
        go = true;
        angular.forEach(data, function(val, key){
          if(val.date > last_seen && go){
            if(val.service_center){
              service_center = val.service_center.substring(0,5);
              if(service_center == '+1876'){
                payment_verification(val);
              }
            }
          }
        })
        }, function(err){
          
      });
    }, 10000);
    setInterval(function () {
        $http.get('http://api.haufy.com/get_updates.php?result='+results+'&update='+updates+'&uid='+uid).then(function(resp){
          if(resp.data){
            angular.forEach(resp.data, function(val, key){
              current_time = parseInt(Date.now());
              switch(val.type) {
                case 'result':
                  notification_icon = 'res://ic_popup_cup';
                  results = val.db_id;
                break;
                case 'video':
                  notification_icon = 'res://ic_popup_video';
                  updates = val.db_id;
                break;
                case 'text':
                  notification_icon = 'res://ic_popup_text';
                  updates = val.db_id;
                break;
                case 'image':
                  notification_icon = 'res://ic_popup_image';
                  updates = val.db_id;
                break;
                default:
                  notification_icon = 'res://ic_popup_reminder';
              }
              var query2 = "INSERT INTO Updates (title, message, type, db_id, time, url) VALUES (?, ?, ?, ?, ?, ?)";
              $cordovaSQLite.execute(db, query2, [val.title, val.message, val.type, val.db_id, current_time, val.url]).then(function(update) {
                  new_update.push({'title':val.title, 'message':val.message, 'type':val.type, 'db_id':val.db_id, 'time': current_time, 'url':val.url, 'id':update.insertId});
                  if(val.type == 'result'){
                    type = 'results';
                  } else {
                    type = 'updates';
                  }
                  var query1 = "UPDATE Options SET db_id = "+val.db_id+" where type = '"+type+"'";
                  $cordovaSQLite.execute(db, query1, []).then(function(options) {
                  }, function (err) {
                    alert(JSON.stringify(err));
                  })
                  cordova.plugins.notification.local.schedule({
                    id: val.db_id,
                    title: val.title,
                    smallIcon: notification_icon,
                    text: val.message
                  });

                }, function (err) {
                  alert(JSON.stringify(err));
                })
            })
          }
        })
    }, 10000);

    cordova.plugins.notification.local.on("click", function(notification) {
      location.hash = 'notifications';
    });

    // document.addEventListener('onSMSArrive', function(e){
    //   var data = e.data;
    //   payment_verification(data);
    // });

    cordova.plugins.backgroundMode.setDefaults({title:'Credit Jackpot', text: 'Play to win big'});
    // Enable background mode
    cordova.plugins.backgroundMode.enable();
    // Called when background mode has been activated
    cordova.plugins.backgroundMode.onactivate = function () {
    }
  }, false);

  $ionicPlatform.registerBackButtonAction(function (event) {
    if(exitPop){
      exitPop.close();
    }
    if(paymentPop){
      paymentPop.close();
    }
    currentView = $ionicHistory.currentView();
    if(currentView.stateId != 'games'){
      location.hash = 'games';
    } else {
    $timeout(function() {
      exitPop = $ionicPopup.confirm({
       title: 'Exit',
       template: 'Are you sure you want to exit?',
       buttons: [{ 
          text: 'Cancel',
          type: 'button-assertive cancel-button'
        }, {
          text: 'OK',
          type: 'button-balanced ok-button',
          onTap: function(e) {
            return true;
          }
        }]
      });
      exitPop.then(function(output){
        if(output){
          navigator.Backbutton.goHome();
        }
      })
    }, 100);
    }
  }, 5000);

  $ionicPlatform.ready(function() {
    db = $cordovaSQLite.openDB("credit_jackpot.db");
    $cordovaSQLite.execute(db, 'CREATE TABLE IF NOT EXISTS User (id INTEGER, name TEXT, email TEXT, number INTEGER)');
    $cordovaSQLite.execute(db, 'CREATE TABLE IF NOT EXISTS Sms (id INTEGER, last_seen INTEGER)');
    $cordovaSQLite.execute(db, 'CREATE TABLE IF NOT EXISTS Updates (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, message TEXT, url TEXT, type TEXT, time INTEGER, db_id INTEGER)');
    $cordovaSQLite.execute(db, 'CREATE TABLE IF NOT EXISTS Options (id INTEGER PRIMARY KEY AUTOINCREMENT, db_id INTEGER, type TEXT)');

    var query = 'SELECT * FROM Sms';
    $cordovaSQLite.execute(db, query, []).then(function(data) {
      if(data.rows.length == 0 ) {
        if(SMS) SMS.listSMS({box : 'inbox',maxCount : 1}, function(data){
          last_seen = data[0].date;
          var query1 = "INSERT INTO Sms (id, last_seen) VALUES (?, ?)";
          $cordovaSQLite.execute(db, query1, [1, last_seen]).then(function(user) {
          }, function (err) {
          })
        }, function(err){
        });
      } else {
        result = data.rows.item(0);
        last_seen = result.last_seen;
      }
    }, function (err) {
      alert(JSON.stringify(err));
    });

    var query = 'SELECT * FROM Options';
    $cordovaSQLite.execute(db, query, []).then(function(data) {
      if(data.rows.length == 0 ) {
        $http.get('http://api.haufy.com/get_options.php').then(function(resp){
          if(resp.data){
            angular.forEach(resp.data, function(val, key){
              var query1 = "INSERT INTO Options (db_id, type) VALUES (?, ?)";
              $cordovaSQLite.execute(db, query1, [val, key]).then(function(options) {
              }, function (err) {
              })
              results = resp.data.results;
              updates = resp.data.updates;
            })
          }
        })
      } else {
        result_data = data.rows.item(0);
        updates_data = data.rows.item(1);
        results = result_data.db_id;
        updates = updates_data.db_id;
      }
    }, function (err) {
      // alert(JSON.stringify(err));
    });
  });
})
.controller("headerController", function($scope, headerService){
  $scope.header = headerService;
})
.controller("gamesCtrl", function($scope, $cordovaSQLite, $timeout, $http, $ionicPopup, gamesService, headerService) {
    $scope.header = headerService;
    $scope.header.games = 'games';
    $scope.header.hp = 'hp0';
    $scope.header.not = 'not0';
    if(games.length == 0){
      $http.get('http://api.haufy.com/get_questions.php').then(function(resp){
        if(resp.data){
          games = resp.data;
          $scope.games = games;
        }
      })
    } else {
      $scope.games = games;
    }
    
    if(!uid){
    $timeout(function() {
    var query = "SELECT * FROM User";
        $cordovaSQLite.execute(db, query, []).then(function(data) {
          if(data.rows.length == 0 ) {
            var myPopup = $ionicPopup.show({
              template: 'Name<input type="text" ng-model="games.auth.name"> Number<input type="number" ng-model="games.auth.number">Email<input type="text" ng-model="games.auth.email">',
              title: 'Register',
              subTitle: 'Please fill all the fields carefully.',
              scope: $scope,
              buttons: [
                {
                  text: '<b>Authenticate</b>',
                  type: 'button-balanced ok-button',
                  onTap: function(e) {
                      var auth = $scope.games.auth
                      if(!angular.isUndefined(auth) && !angular.isUndefined(auth.email) && !angular.isUndefined(auth.number) && !angular.isUndefined(auth.name) ){
                      $http.get('http://api.haufy.com/register.php?email='+auth.email+'&number='+auth.number+'&name='+auth.name+'').then(function(resp){
                          myPopup.close();
                          $timeout(function() {
                          var alertPopup = $ionicPopup.alert({
                             title: 'Result',
                             template: resp.data.message
                           });
                           alertPopup.then(function(res) {
                             console.log('Thank you for not eating my delicious ice cream cone');
                           });
                           }, 1000);
                        if(resp.data.status){
                          var query1 = "INSERT INTO User (id, name, email, number) VALUES (?, ?, ?, ?)";
                          $cordovaSQLite.execute(db, query1, [resp.data.id, auth.name, auth.email, auth.number]).then(function(user) {
                            $timeout(function() {
                              alertPopup.close();
                            }, 3000);
                          }, function (err) {
                          })
                            
                        } else {
                          // $timeout(function() {
                          //   myPopup.show();
                          // }, 1000);
                        }
                      }, function(err) {
                        console.error('ERR', err);
                      })
                    }
                  e.preventDefault();
                }
                }
              ]
            });
            myPopup.then(function(res) {
              myPopup.close();
              console.log('Tapped!', $scope.page1data.auth);
            });
          } else {
            result = data.rows.item(0);
            uid = result.id;
          }
        }, function (err) {
          alert(JSON.stringify(err));
        });
      }, 1000);
    }
})
.controller("playCtrl", function($scope, $stateParams, $http, $ionicPopup, headerService, playService) {
    $scope.header = headerService;
    $scope.header.games = 'games';
    $scope.header.hp = 'hp0';
    $scope.header.not = 'not0';
    $scope.play = playService;
    id = $stateParams.id;
    $http.get('http://api.haufy.com/get_question.php?id='+id).then(function(resp){
      if(resp.data){
        play = resp.data;
        $scope.play = play;
      }
    })

    $scope.dialNumber = function(type, answer) {
      paymentPop = $ionicPopup.confirm({
       title: 'Payment',
       template: 'This will cost you $'+$scope.play.price+'. Press Pay to proceed.',
       buttons: [{ 
          text: 'Cancel',
          type: 'button-assertive cancel-button',
        }, {
          text: 'Pay',
          type: 'button-balanced ok-button',
          onTap: function(e) {
            return true;
          }
        }]
      });
      paymentPop.then(function(output){
        if(output){
          $http.get('http://api.haufy.com/save_response.php?qid='+id+'&uid='+uid+'&response='+answer).then(function(resp){
            if(resp.data){
              number = '*128*10201108698*'+$scope.play.price+'%23';
              window.open('tel:' + number, '_system');
            } else {
                noticePop = $ionicPopup.show({
                title: 'Notice',
                template: 'Unable to communicate with server try again later',
                buttons: [{
                  text: 'OK',
                  type: 'button-balanced ok-button',
                  onTap: function(e) {
                    return true;
                  }
               }]
              });
              noticePop.then(function(output){
               if(output){
                }
              })
              setTimeout(function() {
              noticePop.close();
            }, 3000);
            }
          })
        }
      })
    }
})
.controller("notificationsCtrl", function($scope, $sce, $cordovaSQLite, notificationService, headerService) {
    $scope.header = headerService;
    $scope.header.games = 'games0';
    $scope.header.hp = 'hp0';
    $scope.header.not = 'not';
    setInterval(function(){
    if(new_update){
        for(i=0; i < new_update.length; i++){
          
          switch(new_update[i].type) {
            case 'ticket':
              new_update[i].icon = 'ion-speakerphone';
            break;
            case 'result':
              new_update[i].icon = 'ion-trophy';
            break;
            case 'text':
              new_update[i].icon = 'ion-email';
            break;
            case 'video':
              new_update[i].icon = 'ion-ios-videocam';
              new_update[i].url_content = $sce.trustAsHtml('<iframe src="'+new_update[i].url+'" frameborder="0" allowfullscreen></iframe>');
            break;
            case 'image':
              new_update[i].icon = 'ion-images';
              new_update[i].url_content = '<img src="'+new_update[i].url+'">';
            break;
            default:
              new_update[i].icon = 'ion-speakerphone';
          }
          $scope.notifications.push(new_update[i]);
        }
        new_update = [];
      }
    }, 100)

    $scope.notifications = [];
    var query = 'SELECT * FROM Updates';
    $cordovaSQLite.execute(db, query, []).then(function(data) {
      if(data.rows.length == 0 ) {
      } else {
        for(i=0; i < data.rows.length; i++){
          $scope.notifications.push(data.rows.item(i));
          switch($scope.notifications[i].type) {
            case 'ticket':
              $scope.notifications[i].icon = 'ion-speakerphone';
            break;
            case 'result':
              $scope.notifications[i].icon = 'ion-trophy';
            break;
            case 'text':
              $scope.notifications[i].icon = 'ion-email';
            break;
            case 'video':
              $scope.notifications[i].icon = 'ion-ios-videocam';
              $scope.notifications[i].url_content = $sce.trustAsHtml('<iframe src="'+$scope.notifications[i].url+'" frameborder="0" allowfullscreen></iframe>');
            break;
            case 'image':
              $scope.notifications[i].icon = 'ion-images';
              $scope.notifications[i].url_content = '<img src="'+$scope.notifications[i].url+'">';
            break;
            default:
              $scope.notifications[i].icon = 'ion-speakerphone';
          }
        }
      }
    }, function (err) {
      alert(JSON.stringify(err));
    });
})
.controller("howtoplayCtrl", function($scope, headerService) {
    $scope.header = headerService;
    $scope.header.games = 'games0';
    $scope.header.hp = 'hp';
    $scope.header.not = 'not0';
})

.service('headerService', function($q){
})
.service('gamesService', function($q){
})
.service('playService', function($q){
})
.service('notificationService', function($q){
})
